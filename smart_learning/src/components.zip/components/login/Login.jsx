import "./Login.css";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import { useState } from 'react';
import { useAuth } from '../../AuthContext';

function Login() {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const navigate = useNavigate();
  const [loginError, setLoginError] = useState("");
  const { login } = useAuth();

  const onUserSignin = async (data) => {
    try {
      const { email, password } = data;
      const result = await axios.post("http://localhost:3001/login", 
        { email, password }, 
        { withCredentials: true }
      );

      if (result.status === 200) {
        login();
        navigate('/WebHome', { state: { user: result.data.user } });
      } else {
        console.log("Login failed:", result.data.error || "Unknown error");
      }
    } catch (err) {
      if (err.response && err.response.status === 401) { 
        setLoginError("Invalid email or password.");
      } else {
        console.error("Login error:", err.response?.data?.error || err.message);
      }
    }
  };

  return (
    <div className="container">
      <div className="signin-container">
        <div className="signin-leftmenu">
          <h2>Welcome Back</h2>
          <p>Please sign in to continue</p>
        </div>
        <div className="signin-form-wrapper">
          <form onSubmit={handleSubmit(onUserSignin)} className="signin-form">
            <div className="form-group">
              <input
                type="email"
                placeholder="Your Email *"
                className={`form-control ${errors.email ? "is-invalid" : ""}`}
                {...register("email", { required: "Email is required" })}
              />
            </div>

            <div className="form-group">
              <input
                type="password"
                placeholder="Password *"
                className={`form-control ${errors.password ? "is-invalid" : ""}`}
                {...register("password", { required: "Password is required" })}
              />
            </div>

            {loginError && <div className="error-message">{loginError}</div>}

            <button className="btn btn-primary btn-block mt-4" type="submit">
              Sign In
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Login;
