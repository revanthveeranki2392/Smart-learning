import React from 'react';
import { useLocation } from 'react-router-dom';
import './WebHome.css';

const WebHome = () => {
    const location = useLocation();
    const user = location.state?.user;

    console.log("Location state:", location.state); // Debugging line

    return (
        <div className="container">
            <h1>Welcome Home!</h1>
            {user ? (
                <p>Your email: {user.email}</p>
            ) : (
                <p>No user information available.</p>
            )}
        </div>
    );
};

export default WebHome;
