import Select from 'react-select';

const SkillModal = ({ selectedSkill, setSelectedSkill, skillLevel, setSkillLevel, skillOptions, handleAddSkill, closeModal }) => {
  return (
    <div className="modal-background">
      <div className="modal-container">
        <h2>Select a Skill and Level</h2>

        <div className="input-group">
          <Select
            value={selectedSkill}
            onChange={setSelectedSkill}
            options={skillOptions}
            placeholder="Search and select a skill"
            className="select-skill"
          />

          <select 
            value={skillLevel} 
            onChange={(e) => setSkillLevel(e.target.value)}
            className="select-level"
          >
            <option value="">Select Level</option>
            <option value="Beginner">Beginner</option>
            <option value="Intermediate">Intermediate</option>
            <option value="Advanced">Advanced</option>
          </select>

          <button onClick={handleAddSkill} className="ok-btn">OK</button>
          <button onClick={closeModal} className="cancel-btn">Cancel</button>
        </div>
      </div>
    </div>
  );
};

export default SkillModal;
