function RoutingError()
{
return (
<div>Error 404 page not found</div>
);

}
export default RoutingError 